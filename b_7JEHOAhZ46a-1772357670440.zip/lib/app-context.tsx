"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"

export interface GlucoseReading {
  date: string
  glucose: number
  bmi?: number
  heartRate?: number
  systolic?: number
  diastolic?: number
}

export interface ScanResult {
  riskLevel: "Normal" | "Prediabetic" | "Diabetic"
  confidence: number
  glucoseAvg: number
  bmiValue: number
  heartRate: number
  readings: GlucoseReading[]
  recommendations: string[]
}

export interface Alert {
  id: string
  type: "spike" | "hypo" | "normal" | "warning"
  title: string
  message: string
  timestamp: number
  read: boolean
}

export interface ChatMessage {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: number
}

export interface Consultation {
  id: string
  patientName: string
  doctorName: string
  date: string
  notes: string
  status: "completed" | "pending" | "cancelled"
  riskLevel: "Normal" | "Prediabetic" | "Diabetic"
}

export interface Appointment {
  id: string
  patientName: string
  doctorName: string
  date: string
  time: string
  type: "checkup" | "followup" | "emergency" | "consultation"
  status: "scheduled" | "completed" | "cancelled"
  notes?: string
}

interface AppContextType {
  isAuthenticated: boolean
  user: { name: string; email: string; role: "Patient" | "Doctor" | "Admin" } | null
  login: (email: string, password: string) => Promise<boolean>
  signup: (name: string, email: string, password: string, role: string) => Promise<boolean>
  logout: () => void
  scanResult: ScanResult | null
  setScanResult: (result: ScanResult | null) => void
  isScanning: boolean
  setIsScanning: (v: boolean) => void
  alerts: Alert[]
  addAlert: (alert: Omit<Alert, "id" | "timestamp" | "read">) => void
  markAlertRead: (id: string) => void
  chatMessages: ChatMessage[]
  addChatMessage: (msg: Omit<ChatMessage, "id" | "timestamp">) => void
  consultations: Consultation[]
  addConsultation: (c: Omit<Consultation, "id">) => void
  appointments: Appointment[]
  addAppointment: (a: Omit<Appointment, "id">) => void
  updateAppointment: (id: string, status: Appointment["status"]) => void
}

const AppContext = createContext<AppContextType | undefined>(undefined)

const DEMO_READINGS: GlucoseReading[] = [
  { date: "Jan 1", glucose: 95, bmi: 24.2, heartRate: 72, systolic: 118, diastolic: 76 },
  { date: "Jan 8", glucose: 102, bmi: 24.3, heartRate: 74, systolic: 120, diastolic: 78 },
  { date: "Jan 15", glucose: 110, bmi: 24.5, heartRate: 76, systolic: 122, diastolic: 79 },
  { date: "Jan 22", glucose: 118, bmi: 24.8, heartRate: 78, systolic: 126, diastolic: 82 },
  { date: "Jan 29", glucose: 130, bmi: 25.1, heartRate: 80, systolic: 130, diastolic: 84 },
  { date: "Feb 5", glucose: 142, bmi: 25.4, heartRate: 82, systolic: 134, diastolic: 86 },
  { date: "Feb 12", glucose: 155, bmi: 25.6, heartRate: 84, systolic: 138, diastolic: 88 },
  { date: "Feb 19", glucose: 148, bmi: 25.5, heartRate: 81, systolic: 132, diastolic: 85 },
  { date: "Feb 26", glucose: 160, bmi: 25.8, heartRate: 86, systolic: 140, diastolic: 90 },
  { date: "Mar 5", glucose: 145, bmi: 25.3, heartRate: 79, systolic: 128, diastolic: 83 },
  { date: "Mar 12", glucose: 138, bmi: 25.0, heartRate: 77, systolic: 124, diastolic: 80 },
  { date: "Mar 19", glucose: 128, bmi: 24.7, heartRate: 75, systolic: 121, diastolic: 78 },
]

const INITIAL_ALERTS: Alert[] = [
  {
    id: "1",
    type: "spike",
    title: "Glucose Spike Detected",
    message: "Your glucose level reached 160 mg/dL at 2:30 PM. Consider a short walk and hydration.",
    timestamp: 1740800000000,
    read: false,
  },
  {
    id: "2",
    type: "warning",
    title: "Elevated Heart Rate",
    message: "Heart rate recorded at 86 BPM during resting period. Monitor closely.",
    timestamp: 1740793000000,
    read: false,
  },
  {
    id: "3",
    type: "normal",
    title: "Morning Check Complete",
    message: "Fasting glucose: 95 mg/dL. Within normal range. Great start to the day!",
    timestamp: 1740770000000,
    read: true,
  },
]

const INITIAL_CONSULTATIONS: Consultation[] = [
  {
    id: "c1",
    patientName: "Demo User",
    doctorName: "Dr. Sarah Chen",
    date: "2026-02-28",
    notes: "Reviewed glucose trends. Patient showing improvement with diet modifications. Glucose average dropped from 145 to 128 mg/dL. Recommended continuing current lifestyle changes.",
    status: "completed",
    riskLevel: "Prediabetic",
  },
  {
    id: "c2",
    patientName: "Demo User",
    doctorName: "Dr. James Wilson",
    date: "2026-02-20",
    notes: "Initial assessment. Patient referred for AI-powered glucose monitoring. BMI at 25.3 - slight overweight category. Prescribed dietary plan and exercise routine.",
    status: "completed",
    riskLevel: "Prediabetic",
  },
  {
    id: "c3",
    patientName: "Demo User",
    doctorName: "Dr. Sarah Chen",
    date: "2026-03-05",
    notes: "Follow-up scheduled to review 30-day glucose data and AI prediction trends.",
    status: "pending",
    riskLevel: "Prediabetic",
  },
]

const INITIAL_APPOINTMENTS: Appointment[] = [
  {
    id: "a1",
    patientName: "Demo User",
    doctorName: "Dr. Sarah Chen",
    date: "2026-03-05",
    time: "10:00 AM",
    type: "followup",
    status: "scheduled",
    notes: "30-day glucose review",
  },
  {
    id: "a2",
    patientName: "Demo User",
    doctorName: "Dr. James Wilson",
    date: "2026-03-12",
    time: "2:30 PM",
    type: "checkup",
    status: "scheduled",
    notes: "Quarterly metabolic panel",
  },
  {
    id: "a3",
    patientName: "Demo User",
    doctorName: "Dr. Sarah Chen",
    date: "2026-02-28",
    time: "11:00 AM",
    type: "consultation",
    status: "completed",
    notes: "Diet plan review and adjustment",
  },
  {
    id: "a4",
    patientName: "Demo User",
    doctorName: "Dr. James Wilson",
    date: "2026-02-15",
    time: "9:00 AM",
    type: "checkup",
    status: "completed",
    notes: "Initial health assessment",
  },
]

export function AppProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [user, setUser] = useState<AppContextType["user"]>(null)
  const [scanResult, setScanResult] = useState<ScanResult | null>(null)
  const [isScanning, setIsScanning] = useState(false)
  const [alerts, setAlerts] = useState<Alert[]>(INITIAL_ALERTS)
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])
  const [consultations, setConsultations] = useState<Consultation[]>(INITIAL_CONSULTATIONS)
  const [appointments, setAppointments] = useState<Appointment[]>(INITIAL_APPOINTMENTS)

  const login = useCallback(async (email: string, _password: string) => {
    await new Promise((r) => setTimeout(r, 1200))
    setIsAuthenticated(true)
    setUser({ name: email.split("@")[0], email, role: "Patient" })
    return true
  }, [])

  const signup = useCallback(async (name: string, email: string, _password: string, role: string) => {
    await new Promise((r) => setTimeout(r, 1200))
    setIsAuthenticated(true)
    setUser({ name, email, role: role as "Patient" | "Doctor" | "Admin" })
    return true
  }, [])

  const logout = useCallback(() => {
    setIsAuthenticated(false)
    setUser(null)
    setScanResult(null)
  }, [])

  const addAlert = useCallback((alert: Omit<Alert, "id" | "timestamp" | "read">) => {
    setAlerts((prev) => [
      { ...alert, id: Date.now().toString(), timestamp: Date.now(), read: false },
      ...prev,
    ])
  }, [])

  const markAlertRead = useCallback((id: string) => {
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, read: true } : a)))
  }, [])

  const addChatMessage = useCallback((msg: Omit<ChatMessage, "id" | "timestamp">) => {
    setChatMessages((prev) => [...prev, { ...msg, id: Date.now().toString(), timestamp: Date.now() }])
  }, [])

  const addConsultation = useCallback((c: Omit<Consultation, "id">) => {
    setConsultations((prev) => [{ ...c, id: Date.now().toString() }, ...prev])
  }, [])

  const addAppointment = useCallback((a: Omit<Appointment, "id">) => {
    setAppointments((prev) => [{ ...a, id: Date.now().toString() }, ...prev])
  }, [])

  const updateAppointment = useCallback((id: string, status: Appointment["status"]) => {
    setAppointments((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)))
  }, [])

  return (
    <AppContext.Provider
      value={{
        isAuthenticated,
        user,
        login,
        signup,
        logout,
        scanResult,
        setScanResult,
        isScanning,
        setIsScanning,
        alerts,
        addAlert,
        markAlertRead,
        chatMessages,
        addChatMessage,
        consultations,
        addConsultation,
        appointments,
        addAppointment,
        updateAppointment,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error("useApp must be used within AppProvider")
  return ctx
}

export { DEMO_READINGS }
