"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import {
  Activity,
  Brain,
  FileText,
  MessageSquare,
  Shield,
  ArrowRight,
  ChevronDown,
  Mail,
  MapPin,
  Phone,
} from "lucide-react"
import { Button } from "@/components/ui/button"

function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) setIsVisible(true)
    }, { threshold })
    observer.observe(el)
    return () => observer.unobserve(el)
  }, [threshold])
  return { ref, isVisible }
}

function FadeInSection({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const { ref, isVisible } = useInView()
  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  )
}

const features = [
  {
    icon: FileText,
    title: "Smart Document Scanning",
    desc: "Upload medical reports and let our AI extract glucose, BMI, and vital data automatically using advanced OCR.",
  },
  {
    icon: Brain,
    title: "AI Predictive Analysis",
    desc: "Custom LSTM/CNN models classify your risk level as Normal, Prediabetic, or Diabetic with high accuracy.",
  },
  {
    icon: Activity,
    title: "Interactive Dashboards",
    desc: "Real-time glucose trends, heart rate variability, and BMI tracking with beautiful interactive charts.",
  },
  {
    icon: MessageSquare,
    title: "AI Health Consultant",
    desc: "24/7 AI-powered chatbot for personalized diet, lifestyle, and health management recommendations.",
  },
  {
    icon: Shield,
    title: "Real-time Alerts",
    desc: "Instant notifications for glucose spikes, hypoglycemia, and critical health events.",
  },
]

export default function LandingPage() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handler = () => setScrollY(window.scrollY)
    window.addEventListener("scroll", handler, { passive: true })
    return () => window.removeEventListener("scroll", handler)
  }, [])

  return (
    <div className="min-h-screen relative overflow-x-hidden">
      {/* Ambient background orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute w-[600px] h-[600px] rounded-full opacity-20"
          style={{
            background: "radial-gradient(circle, rgba(0,212,255,0.3), transparent 70%)",
            top: "-200px",
            right: "-100px",
            transform: `translateY(${scrollY * 0.1}px)`,
          }}
        />
        <div
          className="absolute w-[500px] h-[500px] rounded-full opacity-15"
          style={{
            background: "radial-gradient(circle, rgba(0,230,118,0.25), transparent 70%)",
            bottom: "-150px",
            left: "-100px",
            transform: `translateY(${-scrollY * 0.08}px)`,
          }}
        />
      </div>

      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-[rgba(255,255,255,0.08)]">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#00d4ff] to-[#00e676] flex items-center justify-center">
              <Activity className="w-5 h-5 text-[#040d1a]" />
            </div>
            <span className="text-lg font-bold text-[#e8f0fe]">GlucoVision AI</span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <a href="#about" className="text-sm text-[#7a8ba3] hover:text-[#00d4ff] transition-colors">About</a>
            <a href="#features" className="text-sm text-[#7a8ba3] hover:text-[#00d4ff] transition-colors">Features</a>
            <a href="#contact" className="text-sm text-[#7a8ba3] hover:text-[#00d4ff] transition-colors">Contact</a>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth/login">
              <Button variant="ghost" className="text-[#7a8ba3] hover:text-[#00d4ff] hover:bg-[rgba(0,212,255,0.1)]">
                Log In
              </Button>
            </Link>
            <Link href="/auth/signup">
              <Button className="bg-gradient-to-r from-[#00d4ff] to-[#00e676] text-[#040d1a] font-semibold hover:opacity-90 border-0">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center pt-20">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <FadeInSection>
            <div className="inline-flex items-center gap-2 glass-card px-4 py-2 mb-8">
              <div className="w-2 h-2 rounded-full bg-[#00e676] animate-pulse" />
              <span className="text-sm text-[#7a8ba3]">AI-Powered Diabetes Management</span>
            </div>
          </FadeInSection>

          <FadeInSection delay={100}>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 text-balance">
              <span className="text-[#e8f0fe]">Your Health, </span>
              <span className="text-gradient">Reimagined</span>
              <br />
              <span className="text-[#e8f0fe]">with AI Precision</span>
            </h1>
          </FadeInSection>

          <FadeInSection delay={200}>
            <p className="text-lg md:text-xl text-[#7a8ba3] max-w-2xl mx-auto mb-10 text-pretty">
              GlucoVision AI combines cutting-edge machine learning with real-time health monitoring
              to predict, prevent, and manage diabetes like never before.
            </p>
          </FadeInSection>

          <FadeInSection delay={300}>
            <div className="flex items-center justify-center gap-4 flex-wrap">
              <Link href="/auth/signup">
                <Button size="lg" className="bg-gradient-to-r from-[#00d4ff] to-[#00e676] text-[#040d1a] font-semibold hover:opacity-90 text-base px-8 border-0">
                  Start Free Analysis
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </Link>
              <a href="#about">
                <Button size="lg" variant="outline" className="border-[rgba(255,255,255,0.15)] text-[#e8f0fe] hover:bg-[rgba(255,255,255,0.05)] text-base px-8 bg-transparent">
                  Learn More
                </Button>
              </a>
            </div>
          </FadeInSection>

          {/* Floating stat cards */}
          <FadeInSection delay={500}>
            <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
              {[
                { label: "Accuracy Rate", value: "97.8%", color: "#00d4ff", delay: "0s" },
                { label: "Reports Analyzed", value: "50K+", color: "#00e676", delay: "0.5s" },
                { label: "Active Users", value: "12K+", color: "#ffb300", delay: "1s" },
              ].map((stat) => (
                <div key={stat.label} className="glass-card p-6 animate-float" style={{ animationDelay: stat.delay }}>
                  <p className="text-3xl font-bold" style={{ color: stat.color }}>{stat.value}</p>
                  <p className="text-sm text-[#7a8ba3] mt-1">{stat.label}</p>
                </div>
              ))}
            </div>
          </FadeInSection>

          <div className="mt-16">
            <a href="#about" aria-label="Scroll to about section">
              <ChevronDown className="w-6 h-6 text-[#7a8ba3] mx-auto animate-bounce" />
            </a>
          </div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="py-24 relative">
        <div className="max-w-7xl mx-auto px-6">
          <FadeInSection>
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#e8f0fe] mb-4 text-balance">
                Why GlucoVision AI?
              </h2>
              <p className="text-[#7a8ba3] max-w-xl mx-auto text-pretty">
                We leverage advanced artificial intelligence to transform raw health data into actionable insights,
                empowering you to take control of your well-being.
              </p>
            </div>
          </FadeInSection>

          <div className="grid md:grid-cols-2 gap-8 items-center">
            <FadeInSection>
              <div className="glass-card p-8 space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-[rgba(0,212,255,0.15)] flex items-center justify-center shrink-0">
                    <Brain className="w-5 h-5 text-[#00d4ff]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#e8f0fe] mb-1">Deep Learning Models</h3>
                    <p className="text-sm text-[#7a8ba3]">
                      Our LSTM and CNN models are trained on millions of health records to predict diabetes risk with unprecedented accuracy.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-[rgba(0,230,118,0.15)] flex items-center justify-center shrink-0">
                    <Shield className="w-5 h-5 text-[#00e676]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#e8f0fe] mb-1">Privacy First</h3>
                    <p className="text-sm text-[#7a8ba3]">
                      End-to-end encryption ensures your health data remains private and secure at all times.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-[rgba(255,179,0,0.15)] flex items-center justify-center shrink-0">
                    <Activity className="w-5 h-5 text-[#ffb300]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#e8f0fe] mb-1">Real-time Monitoring</h3>
                    <p className="text-sm text-[#7a8ba3]">
                      Continuous health tracking with instant alerts for any anomalies or concerning patterns.
                    </p>
                  </div>
                </div>
              </div>
            </FadeInSection>

            <FadeInSection delay={200}>
              <div className="glass-card p-1 glow-cyan">
                <div className="bg-[rgba(4,13,26,0.8)] rounded-[calc(var(--radius)-4px)] p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-3 h-3 rounded-full bg-[#ff4c6a]" />
                    <div className="w-3 h-3 rounded-full bg-[#ffb300]" />
                    <div className="w-3 h-3 rounded-full bg-[#00e676]" />
                  </div>
                  <pre className="text-xs text-[#7a8ba3] font-mono leading-relaxed">
{`{
  "patient_id": "GV-2026-4821",
  "analysis": {
    "risk_level": "Prediabetic",
    "confidence": 0.934,
    "glucose_avg": 128.5,
    "bmi": 25.3,
    "recommendation": "Lifestyle modification"
  },
  "model": "GlucoVision-LSTM-v3",
  "timestamp": "2026-03-01T10:30:00Z"
}`}
                  </pre>
                </div>
              </div>
            </FadeInSection>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-24 relative">
        <div className="max-w-7xl mx-auto px-6">
          <FadeInSection>
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#e8f0fe] mb-4 text-balance">
                Powerful Features
              </h2>
              <p className="text-[#7a8ba3] max-w-xl mx-auto text-pretty">
                Everything you need to understand, manage, and improve your health in one intelligent platform.
              </p>
            </div>
          </FadeInSection>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <FadeInSection key={f.title} delay={i * 100}>
                <div className="glass-card p-6 h-full hover:border-[rgba(0,212,255,0.3)] transition-all duration-300 group">
                  <div className="w-12 h-12 rounded-xl bg-[rgba(0,212,255,0.1)] flex items-center justify-center mb-4 group-hover:bg-[rgba(0,212,255,0.2)] transition-colors">
                    <f.icon className="w-6 h-6 text-[#00d4ff]" />
                  </div>
                  <h3 className="text-lg font-semibold text-[#e8f0fe] mb-2">{f.title}</h3>
                  <p className="text-sm text-[#7a8ba3] leading-relaxed">{f.desc}</p>
                </div>
              </FadeInSection>
            ))}

            <FadeInSection delay={500}>
              <Link href="/auth/signup" className="block h-full">
                <div className="glass-card p-6 h-full flex flex-col items-center justify-center border-dashed border-[rgba(0,212,255,0.3)] hover:border-[rgba(0,212,255,0.5)] transition-all duration-300 group cursor-pointer">
                  <div className="w-12 h-12 rounded-full bg-[rgba(0,212,255,0.1)] flex items-center justify-center mb-4 group-hover:bg-[rgba(0,212,255,0.2)] transition-colors">
                    <ArrowRight className="w-6 h-6 text-[#00d4ff]" />
                  </div>
                  <p className="text-[#00d4ff] font-semibold">Get Started Now</p>
                  <p className="text-sm text-[#7a8ba3] mt-1">Free health analysis</p>
                </div>
              </Link>
            </FadeInSection>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-24 relative">
        <div className="max-w-7xl mx-auto px-6">
          <FadeInSection>
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#e8f0fe] mb-4 text-balance">
                Get in Touch
              </h2>
              <p className="text-[#7a8ba3] max-w-xl mx-auto text-pretty">
                Have questions about GlucoVision AI? Our team is here to help you start your health journey.
              </p>
            </div>
          </FadeInSection>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <FadeInSection>
              <div className="glass-card p-8">
                <h3 className="text-xl font-semibold text-[#e8f0fe] mb-6">Send us a Message</h3>
                <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                  <div>
                    <label htmlFor="contact-name" className="text-sm text-[#7a8ba3] mb-1 block">Name</label>
                    <input
                      id="contact-name"
                      type="text"
                      className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] placeholder:text-[#4a5568] focus:border-[#00d4ff] focus:outline-none transition-colors"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label htmlFor="contact-email" className="text-sm text-[#7a8ba3] mb-1 block">Email</label>
                    <input
                      id="contact-email"
                      type="email"
                      className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] placeholder:text-[#4a5568] focus:border-[#00d4ff] focus:outline-none transition-colors"
                      placeholder="you@example.com"
                    />
                  </div>
                  <div>
                    <label htmlFor="contact-message" className="text-sm text-[#7a8ba3] mb-1 block">Message</label>
                    <textarea
                      id="contact-message"
                      rows={4}
                      className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] placeholder:text-[#4a5568] focus:border-[#00d4ff] focus:outline-none transition-colors resize-none"
                      placeholder="How can we help?"
                    />
                  </div>
                  <Button className="w-full bg-gradient-to-r from-[#00d4ff] to-[#00e676] text-[#040d1a] font-semibold hover:opacity-90 border-0">
                    Send Message
                  </Button>
                </form>
              </div>
            </FadeInSection>

            <FadeInSection delay={200}>
              <div className="space-y-6">
                {[
                  { icon: Mail, label: "Email", value: "support@glucovision.ai" },
                  { icon: Phone, label: "Phone", value: "+1 (555) 0123-4567" },
                  { icon: MapPin, label: "Address", value: "100 Health Innovation Drive\nSan Francisco, CA 94105" },
                ].map((item) => (
                  <div key={item.label} className="glass-card p-6 flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-[rgba(0,212,255,0.1)] flex items-center justify-center shrink-0">
                      <item.icon className="w-5 h-5 text-[#00d4ff]" />
                    </div>
                    <div>
                      <p className="font-semibold text-[#e8f0fe]">{item.label}</p>
                      <p className="text-sm text-[#7a8ba3] whitespace-pre-line">{item.value}</p>
                    </div>
                  </div>
                ))}
              </div>
            </FadeInSection>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[rgba(255,255,255,0.08)] py-8">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-gradient-to-br from-[#00d4ff] to-[#00e676] flex items-center justify-center">
              <Activity className="w-4 h-4 text-[#040d1a]" />
            </div>
            <span className="text-sm font-semibold text-[#e8f0fe]">GlucoVision AI</span>
          </div>
          <p className="text-xs text-[#7a8ba3]">2026 GlucoVision AI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
