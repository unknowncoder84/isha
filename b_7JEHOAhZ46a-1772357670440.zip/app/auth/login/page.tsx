"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Activity, Eye, EyeOff, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useApp } from "@/lib/app-context"

export default function LoginPage() {
  const router = useRouter()
  const { login } = useApp()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!email || !password) {
      setError("Please fill in all fields")
      return
    }
    setError("")
    setLoading(true)
    try {
      await login(email, password)
      router.push("/dashboard")
    } catch {
      setError("Login failed. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      {/* Background orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute w-[500px] h-[500px] rounded-full opacity-20"
          style={{
            background: "radial-gradient(circle, rgba(0,212,255,0.3), transparent 70%)",
            top: "-100px",
            right: "-50px",
          }}
        />
        <div
          className="absolute w-[400px] h-[400px] rounded-full opacity-15"
          style={{
            background: "radial-gradient(circle, rgba(0,230,118,0.25), transparent 70%)",
            bottom: "-100px",
            left: "-50px",
          }}
        />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <Link href="/" className="flex items-center justify-center gap-2 mb-8">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#00d4ff] to-[#00e676] flex items-center justify-center">
            <Activity className="w-6 h-6 text-[#040d1a]" />
          </div>
          <span className="text-xl font-bold text-[#e8f0fe]">GlucoVision AI</span>
        </Link>

        {/* Login card */}
        <div className="glass-card p-8 glow-cyan">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-[#e8f0fe]">Welcome Back</h1>
            <p className="text-sm text-[#7a8ba3] mt-1">Sign in to access your health dashboard</p>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-[rgba(255,76,106,0.1)] border border-[rgba(255,76,106,0.3)] text-sm text-[#ff4c6a]">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="login-email" className="text-sm text-[#7a8ba3] mb-1 block">Email</label>
              <input
                id="login-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] placeholder:text-[#4a5568] focus:border-[#00d4ff] focus:outline-none transition-colors"
                placeholder="you@example.com"
              />
            </div>

            <div>
              <label htmlFor="login-password" className="text-sm text-[#7a8ba3] mb-1 block">Password</label>
              <div className="relative">
                <input
                  id="login-password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] placeholder:text-[#4a5568] focus:border-[#00d4ff] focus:outline-none transition-colors pr-12"
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#7a8ba3] hover:text-[#00d4ff] transition-colors"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-[#00d4ff] to-[#00e676] text-[#040d1a] font-semibold hover:opacity-90 border-0 py-3"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Signing in...
                </>
              ) : (
                "Sign In"
              )}
            </Button>
          </form>

          {/* Divider */}
          <div className="flex items-center gap-3 my-6">
            <div className="flex-1 h-px bg-[rgba(255,255,255,0.1)]" />
            <span className="text-xs text-[#4a5568] uppercase tracking-wider">or</span>
            <div className="flex-1 h-px bg-[rgba(255,255,255,0.1)]" />
          </div>

          {/* Demo Login Button */}
          <button
            type="button"
            disabled={loading}
            onClick={async () => {
              setEmail("demo@glucovision.ai")
              setPassword("demo1234")
              setError("")
              setLoading(true)
              try {
                await login("demo@glucovision.ai", "demo1234")
                router.push("/dashboard")
              } catch {
                setError("Login failed. Please try again.")
              } finally {
                setLoading(false)
              }
            }}
            className="w-full py-3 rounded-lg font-semibold text-sm border border-[#00d4ff] text-[#00d4ff] hover:bg-[rgba(0,212,255,0.1)] transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Entering demo...
              </>
            ) : (
              <>
                <Activity className="w-4 h-4" />
                Try Demo Account
              </>
            )}
          </button>

          <p className="text-xs text-[#4a5568] text-center mt-3">
            demo@glucovision.ai / demo1234
          </p>

          <div className="mt-5 text-center">
            <p className="text-sm text-[#7a8ba3]">
              {"Don't have an account? "}
              <Link href="/auth/signup" className="text-[#00d4ff] hover:underline font-medium">
                Sign up
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
