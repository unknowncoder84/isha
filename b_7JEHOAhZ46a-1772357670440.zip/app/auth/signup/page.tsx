"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Activity, Eye, EyeOff, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useApp } from "@/lib/app-context"

export default function SignupPage() {
  const router = useRouter()
  const { signup } = useApp()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [role, setRole] = useState("Patient")
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!name || !email || !password) {
      setError("Please fill in all fields")
      return
    }
    setError("")
    setLoading(true)
    try {
      await signup(name, email, password, role)
      router.push("/dashboard")
    } catch {
      setError("Signup failed. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute w-[500px] h-[500px] rounded-full opacity-20"
          style={{
            background: "radial-gradient(circle, rgba(0,230,118,0.3), transparent 70%)",
            top: "-100px",
            left: "-50px",
          }}
        />
        <div
          className="absolute w-[400px] h-[400px] rounded-full opacity-15"
          style={{
            background: "radial-gradient(circle, rgba(0,212,255,0.25), transparent 70%)",
            bottom: "-100px",
            right: "-50px",
          }}
        />
      </div>

      <div className="w-full max-w-md relative z-10">
        <Link href="/" className="flex items-center justify-center gap-2 mb-8">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#00d4ff] to-[#00e676] flex items-center justify-center">
            <Activity className="w-6 h-6 text-[#040d1a]" />
          </div>
          <span className="text-xl font-bold text-[#e8f0fe]">GlucoVision AI</span>
        </Link>

        <div className="glass-card p-8 glow-green">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-[#e8f0fe]">Create Account</h1>
            <p className="text-sm text-[#7a8ba3] mt-1">Start your AI-powered health journey</p>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-[rgba(255,76,106,0.1)] border border-[rgba(255,76,106,0.3)] text-sm text-[#ff4c6a]">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="signup-name" className="text-sm text-[#7a8ba3] mb-1 block">Full Name</label>
              <input
                id="signup-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] placeholder:text-[#4a5568] focus:border-[#00e676] focus:outline-none transition-colors"
                placeholder="John Doe"
              />
            </div>

            <div>
              <label htmlFor="signup-email" className="text-sm text-[#7a8ba3] mb-1 block">Email</label>
              <input
                id="signup-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] placeholder:text-[#4a5568] focus:border-[#00e676] focus:outline-none transition-colors"
                placeholder="you@example.com"
              />
            </div>

            <div>
              <label htmlFor="signup-password" className="text-sm text-[#7a8ba3] mb-1 block">Password</label>
              <div className="relative">
                <input
                  id="signup-password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] placeholder:text-[#4a5568] focus:border-[#00e676] focus:outline-none transition-colors pr-12"
                  placeholder="Create a password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#7a8ba3] hover:text-[#00e676] transition-colors"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div>
              <label htmlFor="signup-role" className="text-sm text-[#7a8ba3] mb-1 block">Role</label>
              <select
                id="signup-role"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] focus:border-[#00e676] focus:outline-none transition-colors appearance-none"
              >
                <option value="Patient" className="bg-[#0a192f]">Patient</option>
                <option value="Doctor" className="bg-[#0a192f]">Doctor</option>
                <option value="Admin" className="bg-[#0a192f]">Admin</option>
              </select>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-[#00e676] to-[#00d4ff] text-[#040d1a] font-semibold hover:opacity-90 border-0 py-3"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating account...
                </>
              ) : (
                "Create Account"
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-[#7a8ba3]">
              Already have an account?{" "}
              <Link href="/auth/login" className="text-[#00e676] hover:underline font-medium">
                Sign in
              </Link>
            </p>
          </div>
        </div>

        <p className="text-xs text-[#4a5568] text-center mt-6">
          Demo: Enter any details to create an account
        </p>
      </div>
    </div>
  )
}
