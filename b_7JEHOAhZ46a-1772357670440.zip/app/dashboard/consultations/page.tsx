"use client"

import { useState } from "react"
import {
  ClipboardList,
  Plus,
  CheckCircle2,
  Clock,
  XCircle,
  FileText,
  User,
  Stethoscope,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { useApp } from "@/lib/app-context"

const statusConfig = {
  completed: { icon: CheckCircle2, color: "#00e676", bg: "glass-emerald", label: "Completed" },
  pending: { icon: Clock, color: "#ffb300", bg: "glass-amber", label: "Pending" },
  cancelled: { icon: XCircle, color: "#ff4c6a", bg: "glass-ruby", label: "Cancelled" },
}

const riskConfig = {
  Normal: { color: "#00e676", bg: "glass-emerald" },
  Prediabetic: { color: "#ffb300", bg: "glass-amber" },
  Diabetic: { color: "#ff4c6a", bg: "glass-ruby" },
}

export default function ConsultationsPage() {
  const { consultations, addConsultation, user } = useApp()
  const [showForm, setShowForm] = useState(false)
  const [notes, setNotes] = useState("")
  const [doctorName, setDoctorName] = useState("")
  const [riskLevel, setRiskLevel] = useState<"Normal" | "Prediabetic" | "Diabetic">("Prediabetic")

  function handleAdd(e: React.FormEvent) {
    e.preventDefault()
    if (!notes.trim()) return
    addConsultation({
      patientName: user?.name || "Patient",
      doctorName: doctorName || "Dr. Sarah Chen",
      date: new Date().toISOString().split("T")[0],
      notes: notes.trim(),
      status: "pending",
      riskLevel,
    })
    setNotes("")
    setDoctorName("")
    setShowForm(false)
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#e8f0fe] flex items-center gap-2">
            <ClipboardList className="w-6 h-6 text-[#00d4ff]" />
            Consultation Logs
          </h1>
          <p className="text-sm text-[#7a8ba3]">
            Track all patient-doctor consultations and notes
          </p>
        </div>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="bg-gradient-to-r from-[#00d4ff] to-[#00e676] text-[#040d1a] font-semibold hover:opacity-90 border-0"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Log
        </Button>
      </div>

      {/* New consultation form */}
      {showForm && (
        <form onSubmit={handleAdd} className="glass-card p-6 space-y-4 glow-cyan">
          <h3 className="text-lg font-semibold text-[#e8f0fe]">New Consultation Log</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="doc-name" className="text-sm text-[#7a8ba3] mb-1 block">Doctor Name</label>
              <input
                id="doc-name"
                type="text"
                value={doctorName}
                onChange={(e) => setDoctorName(e.target.value)}
                placeholder="Dr. Sarah Chen"
                className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] placeholder:text-[#4a5568] focus:border-[#00d4ff] focus:outline-none transition-colors"
              />
            </div>
            <div>
              <label htmlFor="risk-select" className="text-sm text-[#7a8ba3] mb-1 block">Risk Level</label>
              <select
                id="risk-select"
                value={riskLevel}
                onChange={(e) => setRiskLevel(e.target.value as "Normal" | "Prediabetic" | "Diabetic")}
                className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] focus:border-[#00d4ff] focus:outline-none transition-colors appearance-none"
              >
                <option value="Normal" className="bg-[#0a192f]">Normal</option>
                <option value="Prediabetic" className="bg-[#0a192f]">Prediabetic</option>
                <option value="Diabetic" className="bg-[#0a192f]">Diabetic</option>
              </select>
            </div>
          </div>
          <div>
            <label htmlFor="cons-notes" className="text-sm text-[#7a8ba3] mb-1 block">Consultation Notes</label>
            <textarea
              id="cons-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
              placeholder="Enter consultation details, observations, and recommendations..."
              className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] placeholder:text-[#4a5568] focus:border-[#00d4ff] focus:outline-none transition-colors resize-none"
            />
          </div>
          <div className="flex gap-3">
            <Button type="submit" className="bg-gradient-to-r from-[#00d4ff] to-[#00e676] text-[#040d1a] font-semibold hover:opacity-90 border-0">
              Save Log
            </Button>
            <Button type="button" variant="ghost" onClick={() => setShowForm(false)} className="text-[#7a8ba3] hover:text-[#e8f0fe]">
              Cancel
            </Button>
          </div>
        </form>
      )}

      {/* Consultation list */}
      <div className="space-y-4">
        {consultations.length === 0 ? (
          <div className="glass-card p-12 text-center">
            <FileText className="w-10 h-10 text-[#7a8ba3] mx-auto mb-3" />
            <p className="text-[#7a8ba3]">No consultation logs yet.</p>
          </div>
        ) : (
          consultations.map((c) => {
            const sConf = statusConfig[c.status]
            const rConf = riskConfig[c.riskLevel]
            const StatusIcon = sConf.icon
            return (
              <div key={c.id} className="glass-card p-6 hover:border-[rgba(255,255,255,0.2)] transition-all duration-300">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center glass ${sConf.bg}`}>
                      <StatusIcon className="w-5 h-5" style={{ color: sConf.color }} />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-[#e8f0fe]">{c.date}</p>
                      <p className="text-xs text-[#7a8ba3]">{sConf.label}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span
                      className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold glass ${rConf.bg}`}
                      style={{ color: rConf.color }}
                    >
                      {c.riskLevel}
                    </span>
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-3 mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <User className="w-4 h-4 text-[#7a8ba3]" />
                    <span className="text-[#7a8ba3]">Patient:</span>
                    <span className="text-[#e8f0fe]">{c.patientName}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Stethoscope className="w-4 h-4 text-[#7a8ba3]" />
                    <span className="text-[#7a8ba3]">Doctor:</span>
                    <span className="text-[#e8f0fe]">{c.doctorName}</span>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.06)]">
                  <p className="text-sm text-[#c8d6e5] leading-relaxed">{c.notes}</p>
                </div>
              </div>
            )
          })
        )}
      </div>
    </div>
  )
}
