"use client"

import { useState } from "react"
import {
  Calendar,
  Plus,
  CheckCircle2,
  Clock,
  XCircle,
  Stethoscope,
  User,
  AlertTriangle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { useApp } from "@/lib/app-context"

const statusConfig = {
  scheduled: { icon: Clock, color: "#00d4ff", bg: "bg-[rgba(0,212,255,0.12)]", label: "Scheduled" },
  completed: { icon: CheckCircle2, color: "#00e676", bg: "glass-emerald", label: "Completed" },
  cancelled: { icon: XCircle, color: "#ff4c6a", bg: "glass-ruby", label: "Cancelled" },
}

const typeConfig: Record<string, { color: string; label: string }> = {
  checkup: { color: "#00d4ff", label: "Check-up" },
  followup: { color: "#00e676", label: "Follow-up" },
  emergency: { color: "#ff4c6a", label: "Emergency" },
  consultation: { color: "#ffb300", label: "Consultation" },
}

export default function AppointmentsPage() {
  const { appointments, addAppointment, updateAppointment, user } = useApp()
  const [showForm, setShowForm] = useState(false)
  const [doctorName, setDoctorName] = useState("")
  const [date, setDate] = useState("")
  const [time, setTime] = useState("")
  const [type, setType] = useState<"checkup" | "followup" | "emergency" | "consultation">("checkup")
  const [notes, setNotes] = useState("")

  const upcoming = appointments.filter((a) => a.status === "scheduled").sort((a, b) => a.date.localeCompare(b.date))
  const past = appointments.filter((a) => a.status !== "scheduled").sort((a, b) => b.date.localeCompare(a.date))

  function handleAdd(e: React.FormEvent) {
    e.preventDefault()
    if (!date || !time) return
    addAppointment({
      patientName: user?.name || "Patient",
      doctorName: doctorName || "Dr. Sarah Chen",
      date,
      time,
      type,
      status: "scheduled",
      notes: notes.trim() || undefined,
    })
    setDoctorName("")
    setDate("")
    setTime("")
    setType("checkup")
    setNotes("")
    setShowForm(false)
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#e8f0fe] flex items-center gap-2">
            <Calendar className="w-6 h-6 text-[#00d4ff]" />
            Appointments
          </h1>
          <p className="text-sm text-[#7a8ba3]">
            Schedule and manage your medical appointments
          </p>
        </div>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="bg-gradient-to-r from-[#00d4ff] to-[#00e676] text-[#040d1a] font-semibold hover:opacity-90 border-0"
        >
          <Plus className="w-4 h-4 mr-2" />
          Book Appointment
        </Button>
      </div>

      {/* Booking form */}
      {showForm && (
        <form onSubmit={handleAdd} className="glass-card p-6 space-y-4 glow-cyan">
          <h3 className="text-lg font-semibold text-[#e8f0fe]">Schedule New Appointment</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="appt-doctor" className="text-sm text-[#7a8ba3] mb-1 block">Doctor</label>
              <input
                id="appt-doctor"
                type="text"
                value={doctorName}
                onChange={(e) => setDoctorName(e.target.value)}
                placeholder="Dr. Sarah Chen"
                className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] placeholder:text-[#4a5568] focus:border-[#00d4ff] focus:outline-none transition-colors"
              />
            </div>
            <div>
              <label htmlFor="appt-type" className="text-sm text-[#7a8ba3] mb-1 block">Type</label>
              <select
                id="appt-type"
                value={type}
                onChange={(e) => setType(e.target.value as typeof type)}
                className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] focus:border-[#00d4ff] focus:outline-none transition-colors appearance-none"
              >
                <option value="checkup" className="bg-[#0a192f]">Check-up</option>
                <option value="followup" className="bg-[#0a192f]">Follow-up</option>
                <option value="consultation" className="bg-[#0a192f]">Consultation</option>
                <option value="emergency" className="bg-[#0a192f]">Emergency</option>
              </select>
            </div>
            <div>
              <label htmlFor="appt-date" className="text-sm text-[#7a8ba3] mb-1 block">Date</label>
              <input
                id="appt-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] focus:border-[#00d4ff] focus:outline-none transition-colors"
              />
            </div>
            <div>
              <label htmlFor="appt-time" className="text-sm text-[#7a8ba3] mb-1 block">Time</label>
              <input
                id="appt-time"
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] focus:border-[#00d4ff] focus:outline-none transition-colors"
              />
            </div>
          </div>
          <div>
            <label htmlFor="appt-notes" className="text-sm text-[#7a8ba3] mb-1 block">Notes (optional)</label>
            <input
              id="appt-notes"
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Reason for appointment..."
              className="w-full px-4 py-3 rounded-lg bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] text-[#e8f0fe] placeholder:text-[#4a5568] focus:border-[#00d4ff] focus:outline-none transition-colors"
            />
          </div>
          <div className="flex gap-3">
            <Button type="submit" className="bg-gradient-to-r from-[#00d4ff] to-[#00e676] text-[#040d1a] font-semibold hover:opacity-90 border-0">
              Schedule
            </Button>
            <Button type="button" variant="ghost" onClick={() => setShowForm(false)} className="text-[#7a8ba3] hover:text-[#e8f0fe]">
              Cancel
            </Button>
          </div>
        </form>
      )}

      {/* Upcoming */}
      <div>
        <h2 className="text-lg font-semibold text-[#e8f0fe] mb-3 flex items-center gap-2">
          <Clock className="w-5 h-5 text-[#00d4ff]" />
          Upcoming ({upcoming.length})
        </h2>
        {upcoming.length === 0 ? (
          <div className="glass-card p-8 text-center">
            <Calendar className="w-8 h-8 text-[#7a8ba3] mx-auto mb-2" />
            <p className="text-sm text-[#7a8ba3]">No upcoming appointments</p>
          </div>
        ) : (
          <div className="space-y-3">
            {upcoming.map((a) => {
              const tConf = typeConfig[a.type]
              return (
                <div key={a.id} className="glass-card p-5 hover:border-[rgba(0,212,255,0.3)] transition-all duration-300">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-xl bg-[rgba(0,212,255,0.08)] flex flex-col items-center justify-center">
                        <span className="text-lg font-bold text-[#00d4ff]">{a.date.split("-")[2]}</span>
                        <span className="text-[10px] text-[#7a8ba3] uppercase">
                          {new Date(a.date + "T00:00:00").toLocaleDateString("en-US", { month: "short" })}
                        </span>
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span
                            className="text-xs px-2 py-0.5 rounded-full font-medium"
                            style={{ background: `${tConf.color}20`, color: tConf.color }}
                          >
                            {tConf.label}
                          </span>
                          <span className="text-sm text-[#00d4ff] font-medium">{a.time}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Stethoscope className="w-3.5 h-3.5 text-[#7a8ba3]" />
                          <span className="text-[#e8f0fe]">{a.doctorName}</span>
                        </div>
                        {a.notes && (
                          <p className="text-xs text-[#7a8ba3] mt-1">{a.notes}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => updateAppointment(a.id, "completed")}
                        className="text-[#00e676] hover:bg-[rgba(0,230,118,0.1)] text-xs"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                        Complete
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => updateAppointment(a.id, "cancelled")}
                        className="text-[#ff4c6a] hover:bg-[rgba(255,76,106,0.1)] text-xs"
                      >
                        <XCircle className="w-3.5 h-3.5 mr-1" />
                        Cancel
                      </Button>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Past */}
      {past.length > 0 && (
        <div>
          <h2 className="text-lg font-semibold text-[#e8f0fe] mb-3 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-[#00e676]" />
            Past Appointments ({past.length})
          </h2>
          <div className="space-y-3">
            {past.map((a) => {
              const sConf = statusConfig[a.status]
              const tConf = typeConfig[a.type]
              const StatusIcon = sConf.icon
              return (
                <div key={a.id} className="glass-card p-5 opacity-70 hover:opacity-100 transition-all duration-300">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center glass ${sConf.bg}`}>
                      <StatusIcon className="w-5 h-5" style={{ color: sConf.color }} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium text-[#e8f0fe]">{a.date}</span>
                        <span className="text-xs text-[#7a8ba3]">{a.time}</span>
                        <span
                          className="text-xs px-2 py-0.5 rounded-full font-medium"
                          style={{ background: `${tConf.color}20`, color: tConf.color }}
                        >
                          {tConf.label}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Stethoscope className="w-3.5 h-3.5 text-[#7a8ba3]" />
                        <span className="text-[#7a8ba3]">{a.doctorName}</span>
                        {a.notes && (
                          <>
                            <span className="text-[#4a5568]">-</span>
                            <span className="text-[#7a8ba3]">{a.notes}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <span className="text-xs font-medium" style={{ color: sConf.color }}>
                      {sConf.label}
                    </span>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
