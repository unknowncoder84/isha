"use client"

import {
  Activity,
  Heart,
  Droplets,
  TrendingUp,
  AlertTriangle,
  Users,
  ClipboardList,
  Calendar,
  Stethoscope,
} from "lucide-react"
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import { useApp, DEMO_READINGS } from "@/lib/app-context"
import Link from "next/link"

function StatusBadge({ level }: { level: string }) {
  const config: Record<string, { bg: string; text: string; label: string }> = {
    Normal: { bg: "glass-emerald", text: "text-[#00e676]", label: "Normal" },
    Prediabetic: { bg: "glass-amber", text: "text-[#ffb300]", label: "Prediabetic" },
    Diabetic: { bg: "glass-ruby", text: "text-[#ff4c6a]", label: "Diabetic" },
  }
  const c = config[level] || config.Normal
  return (
    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold glass ${c.bg} ${c.text}`}>
      {c.label}
    </span>
  )
}

function GlassStatCard({
  icon: Icon,
  label,
  value,
  unit,
  trend,
  color,
  glassClass,
}: {
  icon: React.ElementType
  label: string
  value: string | number
  unit: string
  trend?: string
  color: string
  glassClass?: string
}) {
  return (
    <div className={`glass-card p-6 ${glassClass || ""}`}>
      <div className="flex items-start justify-between mb-4">
        <div
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ background: `${color}20` }}
        >
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        {trend && (
          <span className="text-xs flex items-center gap-1" style={{ color }}>
            <TrendingUp className="w-3 h-3" />
            {trend}
          </span>
        )}
      </div>
      <p className="text-2xl font-bold text-[#e8f0fe]">
        {value}
        <span className="text-sm font-normal text-[#7a8ba3] ml-1">{unit}</span>
      </p>
      <p className="text-sm text-[#7a8ba3] mt-1">{label}</p>
    </div>
  )
}

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number; name: string; color: string }>; label?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="glass-card p-3 text-xs">
      <p className="text-[#e8f0fe] font-semibold mb-1">{label}</p>
      {payload.map((p) => (
        <p key={p.name} style={{ color: p.color }}>
          {p.name}: {p.value}
        </p>
      ))}
    </div>
  )
}

export default function DashboardHome() {
  const { scanResult, user, consultations, appointments } = useApp()
  const readings = scanResult?.readings || DEMO_READINGS
  const latestReading = readings[readings.length - 1]
  const riskLevel = scanResult?.riskLevel || "Prediabetic"

  // Doctor / Admin view
  if (user?.role === "Doctor" || user?.role === "Admin") {
    const pendingConsultations = consultations.filter((c) => c.status === "pending").length
    const scheduledAppts = appointments.filter((a) => a.status === "scheduled").length
    const demoPatients = [
      { name: "Demo User", risk: "Prediabetic", glucose: 128, lastVisit: "Feb 28, 2026" },
      { name: "Alice Johnson", risk: "Normal", glucose: 92, lastVisit: "Feb 25, 2026" },
      { name: "Bob Martinez", risk: "Diabetic", glucose: 168, lastVisit: "Feb 22, 2026" },
      { name: "Carol Williams", risk: "Prediabetic", glucose: 135, lastVisit: "Feb 20, 2026" },
    ]

    const riskColors: Record<string, string> = {
      Normal: "#00e676",
      Prediabetic: "#ffb300",
      Diabetic: "#ff4c6a",
    }

    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-[#e8f0fe]">
            {user.role === "Admin" ? "Admin" : "Doctor"} Dashboard
          </h1>
          <p className="text-sm text-[#7a8ba3]">Manage patients, consultations, and appointments</p>
        </div>

        {/* Stats overview */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="glass-card p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="w-10 h-10 rounded-lg bg-[rgba(0,212,255,0.15)] flex items-center justify-center">
                <Users className="w-5 h-5 text-[#00d4ff]" />
              </div>
            </div>
            <p className="text-2xl font-bold text-[#e8f0fe]">
              {demoPatients.length}
            </p>
            <p className="text-sm text-[#7a8ba3] mt-1">Active Patients</p>
          </div>
          <div className="glass-card p-6 glass-amber">
            <div className="flex items-start justify-between mb-4">
              <div className="w-10 h-10 rounded-lg bg-[rgba(255,179,0,0.15)] flex items-center justify-center">
                <ClipboardList className="w-5 h-5 text-[#ffb300]" />
              </div>
            </div>
            <p className="text-2xl font-bold text-[#e8f0fe]">{pendingConsultations}</p>
            <p className="text-sm text-[#7a8ba3] mt-1">Pending Consultations</p>
          </div>
          <div className="glass-card p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="w-10 h-10 rounded-lg bg-[rgba(0,230,118,0.15)] flex items-center justify-center">
                <Calendar className="w-5 h-5 text-[#00e676]" />
              </div>
            </div>
            <p className="text-2xl font-bold text-[#e8f0fe]">{scheduledAppts}</p>
            <p className="text-sm text-[#7a8ba3] mt-1">Upcoming Appointments</p>
          </div>
          <div className="glass-card p-6 glass-ruby">
            <div className="flex items-start justify-between mb-4">
              <div className="w-10 h-10 rounded-lg bg-[rgba(255,76,106,0.15)] flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-[#ff4c6a]" />
              </div>
            </div>
            <p className="text-2xl font-bold text-[#e8f0fe]">
              {demoPatients.filter((p) => p.risk === "Diabetic").length}
            </p>
            <p className="text-sm text-[#7a8ba3] mt-1">High Risk Patients</p>
          </div>
        </div>

        {/* Patient List */}
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-[#e8f0fe] flex items-center gap-2">
              <Stethoscope className="w-5 h-5 text-[#00d4ff]" />
              Patient Overview
            </h3>
            <Link href="/dashboard/consultations" className="text-sm text-[#00d4ff] hover:underline">
              View All
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[rgba(255,255,255,0.08)]">
                  <th className="text-left text-xs text-[#7a8ba3] uppercase tracking-wider pb-3 font-medium">Patient</th>
                  <th className="text-left text-xs text-[#7a8ba3] uppercase tracking-wider pb-3 font-medium">Risk Level</th>
                  <th className="text-left text-xs text-[#7a8ba3] uppercase tracking-wider pb-3 font-medium">Avg Glucose</th>
                  <th className="text-left text-xs text-[#7a8ba3] uppercase tracking-wider pb-3 font-medium">Last Visit</th>
                </tr>
              </thead>
              <tbody>
                {demoPatients.map((p) => (
                  <tr key={p.name} className="border-b border-[rgba(255,255,255,0.04)] hover:bg-[rgba(255,255,255,0.02)] transition-colors">
                    <td className="py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#00d4ff] to-[#00e676] flex items-center justify-center text-xs font-bold text-[#040d1a]">
                          {p.name.charAt(0)}
                        </div>
                        <span className="text-sm text-[#e8f0fe]">{p.name}</span>
                      </div>
                    </td>
                    <td className="py-3">
                      <span
                        className="text-xs px-2 py-1 rounded-full font-medium"
                        style={{ background: `${riskColors[p.risk]}20`, color: riskColors[p.risk] }}
                      >
                        {p.risk}
                      </span>
                    </td>
                    <td className="py-3 text-sm text-[#e8f0fe]">{p.glucose} mg/dL</td>
                    <td className="py-3 text-sm text-[#7a8ba3]">{p.lastVisit}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Also show the glucose chart for reference */}
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold text-[#e8f0fe] mb-1">Population Glucose Trends</h3>
          <p className="text-xs text-[#7a8ba3] mb-4">Average patient glucose levels over time</p>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={readings}>
                <defs>
                  <linearGradient id="glucoseGradDoc" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#00d4ff" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#00d4ff" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="date" tick={{ fill: "#7a8ba3", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#7a8ba3", fontSize: 11 }} axisLine={false} tickLine={false} domain={[80, 180]} />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="glucose"
                  name="Glucose"
                  stroke="#00d4ff"
                  strokeWidth={2}
                  fill="url(#glucoseGradDoc)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    )
  }

  // Patient view (default)
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#e8f0fe]">Health Dashboard</h1>
          <p className="text-sm text-[#7a8ba3]">Monitor your health metrics in real-time</p>
        </div>
        <div className="flex items-center gap-3">
          <StatusBadge level={riskLevel} />
          <span className="text-xs text-[#7a8ba3]">AI Risk Assessment</span>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <GlassStatCard
          icon={Droplets}
          label="Current Glucose"
          value={latestReading.glucose}
          unit="mg/dL"
          trend="-4.2%"
          color="#00d4ff"
        />
        <GlassStatCard
          icon={Activity}
          label="BMI Index"
          value={latestReading.bmi || 24.7}
          unit="kg/m2"
          trend="-1.1%"
          color="#00e676"
          glassClass="glass-emerald"
        />
        <GlassStatCard
          icon={Heart}
          label="Heart Rate"
          value={latestReading.heartRate || 75}
          unit="BPM"
          color="#ffb300"
          glassClass="glass-amber"
        />
        <GlassStatCard
          icon={AlertTriangle}
          label="Blood Pressure"
          value={`${latestReading.systolic || 121}/${latestReading.diastolic || 78}`}
          unit="mmHg"
          color="#ff4c6a"
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Glucose Trend */}
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold text-[#e8f0fe] mb-1">Glucose Trend</h3>
          <p className="text-xs text-[#7a8ba3] mb-4">Blood glucose levels over time (mg/dL)</p>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={readings}>
                <defs>
                  <linearGradient id="glucoseGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#00d4ff" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#00d4ff" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="date" tick={{ fill: "#7a8ba3", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#7a8ba3", fontSize: 11 }} axisLine={false} tickLine={false} domain={[80, 180]} />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="glucose"
                  name="Glucose"
                  stroke="#00d4ff"
                  strokeWidth={2}
                  fill="url(#glucoseGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Heart Rate */}
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold text-[#e8f0fe] mb-1">Heart Rate Variability</h3>
          <p className="text-xs text-[#7a8ba3] mb-4">Resting heart rate (BPM)</p>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={readings}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="date" tick={{ fill: "#7a8ba3", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#7a8ba3", fontSize: 11 }} axisLine={false} tickLine={false} domain={[60, 100]} />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="heartRate"
                  name="Heart Rate"
                  stroke="#ff4c6a"
                  strokeWidth={2}
                  dot={{ fill: "#ff4c6a", r: 3 }}
                  activeDot={{ r: 5, fill: "#ff4c6a" }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* BMI and Blood Pressure charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold text-[#e8f0fe] mb-1">BMI Tracking</h3>
          <p className="text-xs text-[#7a8ba3] mb-4">Body Mass Index over time (kg/m2)</p>
          <div className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={readings}>
                <defs>
                  <linearGradient id="bmiGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#00e676" stopOpacity={0.8} />
                    <stop offset="100%" stopColor="#00e676" stopOpacity={0.2} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="date" tick={{ fill: "#7a8ba3", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#7a8ba3", fontSize: 11 }} axisLine={false} tickLine={false} domain={[22, 28]} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="bmi" name="BMI" fill="url(#bmiGrad)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Blood Pressure chart */}
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold text-[#e8f0fe] mb-1">Blood Pressure</h3>
          <p className="text-xs text-[#7a8ba3] mb-4">Systolic / Diastolic (mmHg)</p>
          <div className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={readings}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="date" tick={{ fill: "#7a8ba3", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#7a8ba3", fontSize: 11 }} axisLine={false} tickLine={false} domain={[60, 150]} />
                <Tooltip content={<CustomTooltip />} />
                <Line type="monotone" dataKey="systolic" name="Systolic" stroke="#ff4c6a" strokeWidth={2} dot={{ fill: "#ff4c6a", r: 2 }} />
                <Line type="monotone" dataKey="diastolic" name="Diastolic" stroke="#ffb300" strokeWidth={2} dot={{ fill: "#ffb300", r: 2 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Quick links: upcoming appointments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-[#e8f0fe] flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#00d4ff]" />
              Upcoming Appointments
            </h3>
            <Link href="/dashboard/appointments" className="text-xs text-[#00d4ff] hover:underline">
              View All
            </Link>
          </div>
          {appointments.filter((a) => a.status === "scheduled").length === 0 ? (
            <p className="text-sm text-[#7a8ba3]">No upcoming appointments</p>
          ) : (
            <div className="space-y-3">
              {appointments
                .filter((a) => a.status === "scheduled")
                .slice(0, 3)
                .map((a) => (
                  <div key={a.id} className="flex items-center gap-3 p-3 rounded-lg glass hover:bg-[rgba(255,255,255,0.03)] transition-colors">
                    <div className="w-10 h-10 rounded-lg bg-[rgba(0,212,255,0.08)] flex flex-col items-center justify-center">
                      <span className="text-sm font-bold text-[#00d4ff]">{a.date.split("-")[2]}</span>
                      <span className="text-[8px] text-[#7a8ba3] uppercase">
                        {new Date(a.date + "T00:00:00").toLocaleDateString("en-US", { month: "short" })}
                      </span>
                    </div>
                    <div>
                      <p className="text-sm text-[#e8f0fe]">{a.doctorName}</p>
                      <p className="text-xs text-[#7a8ba3]">{a.time} - {a.notes || a.type}</p>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>

        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-[#e8f0fe] flex items-center gap-2">
              <ClipboardList className="w-5 h-5 text-[#00e676]" />
              Recent Consultations
            </h3>
            <Link href="/dashboard/consultations" className="text-xs text-[#00d4ff] hover:underline">
              View All
            </Link>
          </div>
          {consultations.length === 0 ? (
            <p className="text-sm text-[#7a8ba3]">No consultations yet</p>
          ) : (
            <div className="space-y-3">
              {consultations.slice(0, 3).map((c) => (
                <div key={c.id} className="flex items-center gap-3 p-3 rounded-lg glass hover:bg-[rgba(255,255,255,0.03)] transition-colors">
                  <div className={`w-2 h-2 rounded-full shrink-0`} style={{ background: c.status === "completed" ? "#00e676" : "#ffb300" }} />
                  <div className="min-w-0">
                    <p className="text-sm text-[#e8f0fe] truncate">{c.doctorName} - {c.date}</p>
                    <p className="text-xs text-[#7a8ba3] truncate">{c.notes}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="glass-card p-6">
        <h3 className="text-lg font-semibold text-[#e8f0fe] mb-4">AI Insights</h3>
        <div className="space-y-3">
          {[
            { text: "Glucose levels showing improving trend over the last 2 weeks", type: "emerald" },
            { text: "BMI slightly elevated at 24.7 - consider increasing daily activity", type: "amber" },
            { text: "Heart rate variability is within normal range", type: "emerald" },
            { text: "Blood pressure readings suggest monitoring for hypertension risk", type: "amber" },
          ].map((insight) => (
            <div
              key={insight.text}
              className={`flex items-center gap-3 p-3 rounded-lg glass ${
                insight.type === "emerald" ? "glass-emerald" : "glass-amber"
              }`}
            >
              <div
                className="w-2 h-2 rounded-full shrink-0"
                style={{ background: insight.type === "emerald" ? "#00e676" : "#ffb300" }}
              />
              <p className="text-sm text-[#e8f0fe]">{insight.text}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
